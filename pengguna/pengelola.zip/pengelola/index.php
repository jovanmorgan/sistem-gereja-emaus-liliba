<!-- index.php -->
<?php
header(header: "Location: dashboard");
exit;
?>